export * from './lib/market-ticker.component';
export * from './lib/market-ticker.module';
