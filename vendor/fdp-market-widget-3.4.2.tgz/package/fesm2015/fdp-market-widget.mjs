import * as i0 from '@angular/core';
import { Component, ChangeDetectionStrategy, Input, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class FdpMarketTickerComponent {
    constructor() {
        this.quotes = [];
        this.delayed = true;
    }
    bySymbol(_, q) {
        return q.symbol;
    }
}
FdpMarketTickerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: FdpMarketTickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
FdpMarketTickerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: FdpMarketTickerComponent, selector: "fdp-market-ticker", inputs: { quotes: "quotes", delayed: "delayed" }, ngImport: i0, template: `
    <div class="fdp-row" *ngFor="let q of quotes; trackBy: bySymbol">
      <span class="fdp-name">{{ q.name }}</span>
      <span class="fdp-price">{{ q.price | number: '1.2-2' }}</span>
      <span class="fdp-chg" [class.fdp-up]="q.change >= 0" [class.fdp-down]="q.change < 0">
        {{ q.change >= 0 ? '+' : '' }}{{ q.change }}%
      </span>
    </div>
    <div class="fdp-attr">Market data &copy; FinData Partners{{ delayed ? ' · delayed 15 min' : '' }}</div>
  `, isInline: true, styles: [":host{display:block}.fdp-row{display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px solid #eef1f6}.fdp-name{flex:1}.fdp-up{color:#1e6b3a}.fdp-down{color:#c8102e}.fdp-attr{font-size:11px;color:#6b7280;margin-top:10px}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: FdpMarketTickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fdp-market-ticker', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="fdp-row" *ngFor="let q of quotes; trackBy: bySymbol">
      <span class="fdp-name">{{ q.name }}</span>
      <span class="fdp-price">{{ q.price | number: '1.2-2' }}</span>
      <span class="fdp-chg" [class.fdp-up]="q.change >= 0" [class.fdp-down]="q.change < 0">
        {{ q.change >= 0 ? '+' : '' }}{{ q.change }}%
      </span>
    </div>
    <div class="fdp-attr">Market data &copy; FinData Partners{{ delayed ? ' · delayed 15 min' : '' }}</div>
  `, styles: [":host{display:block}.fdp-row{display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px solid #eef1f6}.fdp-name{flex:1}.fdp-up{color:#1e6b3a}.fdp-down{color:#c8102e}.fdp-attr{font-size:11px;color:#6b7280;margin-top:10px}\n"] }]
        }], propDecorators: { quotes: [{
                type: Input
            }], delayed: [{
                type: Input
            }] } });

class FdpMarketWidgetModule {
}
FdpMarketWidgetModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: FdpMarketWidgetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
FdpMarketWidgetModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "14.3.0", ngImport: i0, type: FdpMarketWidgetModule, declarations: [FdpMarketTickerComponent], imports: [CommonModule], exports: [FdpMarketTickerComponent] });
FdpMarketWidgetModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: FdpMarketWidgetModule, imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: FdpMarketWidgetModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [FdpMarketTickerComponent],
                    imports: [CommonModule],
                    exports: [FdpMarketTickerComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { FdpMarketTickerComponent, FdpMarketWidgetModule };
//# sourceMappingURL=fdp-market-widget.mjs.map
