/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@fdp/market-widget" />
export * from './public-api';
