Copyright (c) FinData Partners. Commercial license. Redistribution, modification and reverse engineering are prohibited.
(Synthetic vendor package created for a demo; not a real product.)
