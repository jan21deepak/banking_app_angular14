import * as i0 from "@angular/core";
export interface FdpQuote {
    symbol: string;
    name: string;
    price: number;
    change: number;
}
export declare class FdpMarketTickerComponent {
    quotes: FdpQuote[] | null;
    delayed: boolean;
    bySymbol(_: number, q: FdpQuote): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FdpMarketTickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FdpMarketTickerComponent, "fdp-market-ticker", never, { "quotes": "quotes"; "delayed": "delayed"; }, {}, never, never, false>;
}
