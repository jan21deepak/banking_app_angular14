import * as i0 from "@angular/core";
import * as i1 from "./market-ticker.component";
import * as i2 from "@angular/common";
export declare class FdpMarketWidgetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FdpMarketWidgetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FdpMarketWidgetModule, [typeof i1.FdpMarketTickerComponent], [typeof i2.CommonModule], [typeof i1.FdpMarketTickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FdpMarketWidgetModule>;
}
