# @fdp/market-widget 3.4.2

Market ticker widget from FinData Partners (FDP). Licensed to the bank under MSA-2023-0417.

**Supported Angular versions: 13.x–14.x.** Angular 16+ support (v4.0) is on the vendor roadmap, with no committed date.
Running this widget on an unsupported Angular version voids the vendor's support SLA (MSA §7.3).
Do not modify, patch or fork this package (MSA §4.1). Contact Vendor Management for upgrades.
